---
title: 【安卓直装】【SLG】用妹妹的身体做实验
categories: 安卓
tags:
- SLG
- 萝莉
- 小游戏
- 经营模拟
- 策略
- 妹妹
date: 2023-2-17 8:10:00
description: 这个东西是短小精悍，没有结局。总之，多和妹妹做XX的事吧！
index_img: https://img.acgus.top/i/2023/06/4fb3c8b530103544.webp
---
![](https://img.acgus.top/i/2023/06/4fb3c8b530103544.webp)
## 游戏简介：
这个东西是短小精悍，没有结局
总之，多和妹妹做XX的事吧！
![](https://img.acgus.top/i/2023/06/a84638cd44103646-1024x554.webp)




## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1pe5kr8Aw1kdGfl-I-r0hWQ?pwd=ynk3" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:ynk3
