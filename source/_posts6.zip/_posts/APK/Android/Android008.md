---
title: 【安卓直装】【SLG】【生肉】苏菲和艾莉的日常
categories: 安卓
tags:
- SLG
- 萝莉
- 小游戏
- 经营模拟
- 策略
- 生肉
date: 2023-4-21 8:10:00
description: 以Live2D移动的迷你动画集，此作为第十弹
index_img: https://img.acgus.top/i/2023/07/caabf717ae154703.webp
---
![](https://img.acgus.top/i/2023/07/caabf717ae154703.webp)
以Live2D移动的迷你动画集，此作为第十弹
![](https://img.acgus.top/i/2023/07/ae296bfddc154821-1024x565.webp)
![](https://img.acgus.top/i/2023/07/577c7c1b44154822-1024x576.webp)
![](https://img.acgus.top/i/2023/07/9fda629da9154821-1024x573.webp)



## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1nsaG0QdlSaFy1Lti3dETNA?pwd=n5zo" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:n5zo
