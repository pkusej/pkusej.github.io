---
title: 【PC+KR+安卓直装】柚子社作品合集
categories:
- 游戏系列合集
- PC
- KRKR
- 安卓
tags:
- ADV
- 恋爱
- 奇幻
- 和风
- 白毛
- 幼刀
- 纯爱
- 游戏系列合集
- Yuzu-Soft（柚子社）
date: 2022-7-25 8:01:00
description: 柚子社（ゆずソフト，Yuzu-Soft）是一家日本游戏制作公司，前身是同人社团TEAM-EXODUS（チームエグゾーダス）。
index_img: https://shp.qpic.cn/collector/2010522975/0af24297-b03f-45df-893d-f4899fbd209b/0
---
![](https://shp.qpic.cn/collector/2010522975/0af24297-b03f-45df-893d-f4899fbd209b/0)
![](https://img.acgus.top/i/helloimg/ZQrhWm.webp)
柚子社（ゆずソフト，Yuzu-Soft）是一家日本游戏制作公司，前身是同人社团TEAM-EXODUS（チームエグゾーダス）。

公司名称：柚子社
外文名：Yuzu-Soft
总部地点：日本
经营范围：游戏制作
首作：管乐恋曲！~The bonds of melody~ （2006年7月28日）
最新作：星光咖啡馆与死神之蝶 （2019年12月20日）
子品牌：YuzuSoftSour


## **汉化情况：**
PC全系列均已汉化。KRKR版除第二作『Empty × Embryo』汉化组未开放文本，没有汉化，其他十作均可以在手机游玩。

## **发售时间与简介：**
第一作：管乐恋曲！ (原文名称：ぶらばん！～The bonds of melody～) 
发售日期：2006年07月28日
是否汉化：已汉化
详细简介：https://acgus.top/PC/185_0/
![柚子社处女作（存在轻微ntr情节）](https://img.acgus.top/i/helloimg/ZQVaWD.webp)

第二作：E×E (原文名称：Empty × Embryo) 
发售日期：2007年06月01日
是否汉化：已汉化
详细简介：https://acgus.top/PC/186_0/
![探索期的另类作品，可玩性依旧不差](https://img.acgus.top/i/helloimg/ZQVZwK.webp)

第三作：夏空彼方 (夏空的彼岸) (原文名称：夏空カナタ) 
发售日期：2008年05月23日
是否汉化：已汉化
详细简介：https://acgus.top/PC/187_0/
![本社少有的剧情佳作，可惜销量惨淡](https://img.acgus.top/i/helloimg/ZQVPxo.webp)

第四作：天神乱漫 (原文名称：天神乱漫 LUCKY or UNLUCKY!?) 
发售日期：2009年05月29日
是否汉化：已汉化
详细简介：https://acgus.top/PC/188_0/
![对废萌路线的初次试探，也奠定了之后的游戏制作路线](https://img.acgus.top/i/helloimg/ZQVR41.webp)

第五作：noble☆works (原文名称：のーぶる☆わーくす) 
发售日期：2010年12月24日
是否汉化：已汉化
详细简介：https://acgus.top/PC/189_0/
![影武者的贵族学校生活（SD画师こもわた遥华正式加入）](https://img.acgus.top/i/helloimg/ZQVohb.webp)

第六作：DRACU-RIOT!  (原文名称：ドラクリオット) 
发售日期：2012年03月30日
是否汉化：已汉化
详细简介：https://acgus.top/PC/190_0/
![超能力+吸血鬼的魔幻故事（柚子社最强男主）](https://img.acgus.top/i/helloimg/ZQVGCT.webp)

第七作：天色Islenauts （天色幻想岛） (原文名称：天色＊アイルノーツ) 
发售日期：2013年07月26日
是否汉化：已汉化
详细简介：https://acgus.top/PC/191_0/
![又称天色催眠岛（雾）](https://img.acgus.top/i/helloimg/ZQV5Hq.webp)

第八作：魔女的夜宴 (原文名称：サノバウィッチ) 
发售日期：2015年02月27日
是否汉化：已汉化
详细简介：https://acgus.top/PC/192_0/
![柚子社钦定女主绫地宁宁登场（华哥yyds）柚子厨经典招呼出处](https://img.acgus.top/i/helloimg/ZQVB7r.webp)

第九作：千恋＊万花
发售日期：2016年07月29日
是否汉化：已汉化
详细简介：https://acgus.top/PC/193_0/
![柚子社最大欧派出处、幼刀登场](https://img.acgus.top/i/helloimg/ZQryPc.webp)

第十作：谜语小丑 (原文名称：RIDDLE JOKER (リドルジョーカー)) 
发售日期：2018年03月30日
是否汉化：已汉化
详细简介：https://acgus.top/PC/194_0/
![锉刀梗出处、妹妹七海登场](https://img.acgus.top/i/helloimg/ZQrjUh.webp)

第十一作：星光咖啡馆与死神之蝶~~（又称馆死、星巴克与阎王扑棱蛾子、咖啡厅史黛拉与死神之蝶)~~
原文名称：喫茶ステラと死神の蝶) 
发售日期：2019年12月20日
是否汉化：已汉化
详细简介：https://acgus.top/PC/195_0/
![死神来了，死神去了( ﾟ∀。)](https://img.acgus.top/i/weiyun/c18ac3ecf07f738aea6a13766590ab83ffa77da15e7778d6c62fb83e4260c6554a8842d16120310f8b6c0f2ab28ee19e.webp)








## <font color=#FF0000 >**注意事项：**</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具win_7Z或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
**百度网盘下载点：请点击详细介绍页面下载。不要在线解压，以免损坏文件。**