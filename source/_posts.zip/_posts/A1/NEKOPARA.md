---
title: 【PC硬盘+KRKR】【官中】NEKOPARA／猫娘乐园／巧克力与香子兰 1～4 合集
categories: 游戏系列合集
tags:
- ADV
- 猫娘
- 兽耳
- 纯爱
- 动态
- 官中
- 游戏系列合集
- NEKO WORKs社
date: 2022-1-22 0:01:00
description: 拥有与人类相近容貌与寿命“人型猫娘”作为宠物存在的世界为舞台，讲述了离开历史悠久的日式点心老店老家开蛋糕店“La Soleil”的主人公和他饲养的猫娘之间的故事
index_img: https://img.acgus.top/i/weiyun/1ba1f15404855c7ef425ede8f68b23371323d0731c464e2227d80094790ae531a9ac3a29e0629a44830ea3d16a7bafb1.webp
---
《猫娘乐园》是NEKO WORKs制作的恋爱冒险电脑游戏。
作品以与人类拥有相近容貌与寿命的“人型猫娘”作为宠物存在的世界为舞台。
讲述了离开历史悠久的日式点心老店老家开蛋糕店“La Soleil”的主人公和他饲养的猫娘之间的故事。
游戏于2014年12月起在Steam发行全年龄版，支持日语、繁体中文、英语。
游戏还在日本发行成人版，普通版能通过付费外部补丁追加成人内容。
作品另移植至PlayStation 4和任天堂Switch平台，收录了新开场曲与新开场影片、新插图、新剧本，重新录制了全部语音，追加了简体中文。
作品通过众筹制作了OVA《猫娘乐园》《猫娘乐园：小猫之日的约定》，并改编为同名电视动画片。

中文名称：猫娘乐园
原版名称：ネコぱら
英文名称：NEKOPARA
其他名称：巧克力与香子兰、艹猫
游戏类型：视觉小说，恋爱冒险
游戏平台：Steam（个人电脑）、PlayStation 4、任天堂Switch（游戏主机）
地区：日本
开发商：NEKO WORKs，Connect Wizard
发行公司：NEKO WORKs（实体版）、Sekai Project（Steam版）、CFK（主机版）
制作人：Sayori
编剧：雪仁、紫雪夜 
背景音乐：水城新人、Team-OZ、Peak A Soul+
玩家人数：单人
游戏画面：2D，彩色
游戏引擎：E-mote，Adobe After Effects
发行阶段：正式版
结局数：1 个

## 游戏简介：
|<font size=4>**剧情简介：**||
|:----|:----| 
|<font size=1>**《猫娘乐园 Vol.0 水无月猫猫们的日常！》<br/>嘉祥“La Soleil”开店前的故事。水无月大女儿时雨与6位猫娘，跟主人一起早起，一起准备早餐，一起做家务，一起出门，一起准备晚饭，一起洗澡，跟大家一起睡觉。水无月家猫娘们与时雨的平凡假日！**</font>|![](https://img.acgus.top/i/weiyun/ed839c3a987c24fd7af7c8bd2428281af75cbaca470f6bbd6d7631100a696d6a466c3804a0342254bb404aae90095d22.webp)|
|<font size=1>**《猫娘乐园 Vol.1 La Soleil 开店了！》<br/>水无月嘉祥离开了经营着具有悠久传统的日式点心老店的老家，决心以西点师的身份，独立开一间自己的蛋糕店“La Soleil”。但是从老家寄来的搬家行李里头，竟然混进了两只以前在老家养的人型猫，巧克力和香草。即使想将她们退还回去，在她们的苦苦哀求下嘉祥也只好让步。于是就变成了一个人和两只猫一起经营这间“La Soleil”了。为了自己最喜欢的主人，就算失败也要继续努力下去的两只猫娘，共同编织出的一段有点H又温暖人心的猫娘恋爱喜剧，现在将在此开店！**</font>|![](https://img.acgus.top/i/weiyun/1ba1f15404855c7ef425ede8f68b23371323d0731c464e2227d80094790ae531a9ac3a29e0629a44830ea3d16a7bafb1.webp)|
|<font size=1>**《猫娘乐园 Vol.1 La Soleil 开店了！》<br/>水无月嘉祥离开了经营着具有悠久传统的日式点心老店的老家，决心以西点师的身份，独立开一间自己的蛋糕店“La Soleil”。但是从老家寄来的搬家行李里头，竟然混进了两只以前在老家养的人型猫，巧克力和香草。即使想将她们退还回去，在她们的苦苦哀求下嘉祥也只好让步。于是就变成了一个人和两只猫一起经营这间“La Soleil”了。为了自己最喜欢的主人，就算失败也要继续努力下去的两只猫娘，共同编织出的一段有点H又温暖人心的猫娘恋爱喜剧，现在将在此开店！**</font>|![](https://img.acgus.top/i/weiyun/1ba1f15404855c7ef425ede8f68b23371323d0731c464e2227d80094790ae531a9ac3a29e0629a44830ea3d16a7bafb1.webp)|
|<font size=1>**《猫娘乐园 Vol.2 甜蜜猫娘姐妹》<br/>水无月嘉祥经营的糕点店“La Soleil”，今天也和水无月家的猫娘四姐妹+妹妹时雨齐心同力做生意。讲话毒舌不坦率，但其实很能干很会照顾人的大姐红豆、个性直率认真，但总是笨手笨脚又爱逞强的四女椰子。曾经感情比谁都要好的姐妹猫娘，两只却不知何时开始成天吵架吵不停。明明相互为对方着想，却也因为小小的误解，让红豆与椰子的感情掀起一场风波。描写了姐妹猫娘在大小经验中成长的模样与家人间的情感纽带，温馨幽默的猫娘喜剧，今天也准时开店！**</font>|![](https://img.acgus.top/i/weiyun/11c80d2348b2ec82bdd74c3f0758ed7f01df4e6229b06ad275c92159c4c8173cd07e532b745171a91eacff697224da89.webp)|
|<font size=1>**《猫娘乐园 Vol.3 绽香猫娘姐妹》<br/>水无月嘉祥所经营的蛋糕店“La Soleil”里的猫娘情人持续增加，今天也好评营业中。自尊心很强、高傲又时髦的猫娘次女枫，与总是陷入妄想独自一人暴走的三女桂。两只猫在姐妹之中的关系如同至交好友一般，因为一些契机而对梦想感到烦恼的枫。想成为挚友的助力却不知该怎么做才好的桂，描绘一起朝着梦想成长的姐妹俩以及家人间的联系，稍微有点H又温暖人心的猫娘恋爱喜剧今天也开张了！**</font>|![](https://img.acgus.top/i/weiyun/1c3db36318b5804cad42dafa1ca1da79e7c8826595b631d702992744c64a5592d6e64b6af4db6a66955fc0fcce19259d.webp)|
|<font size=1>**《猫娘乐园 Extra 小猫之日的约定》<br/>时间回到嘉祥担任店长的猫娘蛋糕店“La Soleil”开张的半年前，还是小猫的巧克力跟香草刚来到水无月家，还没跟其他猫娘们打成一片的时候。开始用“主人”称呼嘉祥，并且在水无月家度过第一个圣诞节的两人，和嘉祥立下了一个约定。**</font>|![](https://img.acgus.top/i/weiyun/78239048c8d78b9acb8900417e65bc5adc5482524a43e3623b8b66c565e18847446633969289c4a66a29c4fcaebcb4fa.webp)|
|<font size=1>**《猫娘乐园 Vol.4 猫娘与糕点师的圣诞节》<br/>水无月嘉祥所开的蛋糕店受到欢迎，但却仍然没有获得父亲的认可。为了让烦恼的嘉祥转换心情，时雨提议与猫咪来趟温泉旅行。在大家的鼓励下，嘉祥燃起了重新挑战的心情，并决定前往法国去学习，结果在法国那里遇到了新的猫咪......**</font>|![](https://img.acgus.top/i/weiyun/208d083c62840f4e2cc381d3373dcb4eb62c20d0f2a6b8890daf43b4e14256b27ba4faad81ba742918a36dee0378a24e.webp)|

 
**一共6部其中『猫娘乐园 Vol.3 绽香猫娘姐妹！』没有KRKR版：**
猫娘乐园 Vol.0 水无月猫猫们的日常！
猫娘乐园 Vol.1 La Soleil 开店了！
猫娘乐园 Vol.2 甜蜜猫娘姐妹！
猫娘乐园 Vol.3 绽香猫娘姐妹！
猫娘乐园 Extra 小猫之日的约定！
猫娘乐园 Vol.4 猫娘与糕点师的圣诞节：
<br>



## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<font color=#FF0000 size=3>**手机玩家请注意：因为游戏是全程动态立绘，如果遇到，报错，卡住，请尝试模拟器右上角→独立设置→图形渲染器→设置成，OpenGL渲染模式。**</font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1S1FUVBl5TziRC9cICs9dZQ?pwd=e952" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:e952
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>