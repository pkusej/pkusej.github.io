---
title: 【PC硬盘】9-nine系列合集
categories: 游戏系列合集
tags:
- ADV
- 恋爱
- 异能
- 奇幻
- 圣遗物
- 游戏系列合集
- 官中
- PALETTE社
date: 2021-11-28 8:01:00
description: 白巳津川（しろみつがわ）市，唯一的特色也就仅仅只有作为学园都市这点了。新海翔的周遭发生了变化。由于大地震，神社中祭祀白蛇九十九的神器破损，来源于异世界的不可思议的装饰品“Artifact”（アーティファクト）流入了这个世界。
index_img: https://img.acgus.top/i/weiyun/03774be6c79832b2390e7e396537dcfabc75f1c551b046be91e6643d3e3ed93ddd0d0a159a8dd83155e0ba2510d9d882.webp
---
![](https://img.acgus.top/i/weiyun/03774be6c79832b2390e7e396537dcfabc75f1c551b046be91e6643d3e3ed93ddd0d0a159a8dd83155e0ba2510d9d882.webp)
《9-nine-》是日本游戏公司PALETTE（ぱれっと）于2017年最初制作发行的文字冒险游戏系列。

原版名称：9-nine-          
别名：9nine     
游戏类型：ここから始まるADV     
游戏平台：PC     
所属系列：9-nine-     
地区：日本     
开发商：PALETTE（ぱれっと）     
发行公司：PALETTE（ぱれっと）、Sekai Project
销售：Steam     
发行日期：2017年4月28日：9-nine-九次九日九重色、2018年4月27日：9-nine-天色天歌天籁音、2019年2月1日：9-nine-:Episode 1、2019年4月26日：9-nine-春色春恋春熙风、2019年8月17日：9-nine-:Episode 2、2020年4月24日：9-nine-雪色雪花雪余痕          
编剧：かずきふみ          
背景音乐：虻川治     
内容主题：“异能”，“恋爱”，“圣遗物”，“战斗”，”meta ”     
玩家人数：单人     
游戏画面：1280×720以上     
游戏引擎：吉里吉里Z     
游戏分级：EOCS:R18（PC）、Steam：全年龄
最新版本：9-nine-ゆきいろゆきはなゆきのあと
发行阶段：正式版     
媒介：DVD-ROM（PC），数字下载（Steam）     
结局数：2个（9-nine-九次九日九重色）、2个（9-nine-天色天歌天籁音）、2个（9-nine-:Episode 1）、2个（9-nine-春色春恋春熙风）、2个（9-nine-:Episode 2）          
企画：かずきふみ     
原画：和泉つばす     
SD原画：ぺろ

## **背景设定：**
白巳津川（しろみつがわ）市，唯一的特色也就仅仅只有作为学园都市这点了。新海翔的周遭发生了变化。由于大地震，神社中祭祀白蛇九十九的神器破损，来源于异世界的不可思议的装饰品“Artifact”（アーティファクト）流入了这个世界。

## 游戏简介：
九条都线路，系列第一部《9-nine-九次九日九重色》（原名：9-nine-ここのつここのかここのいろ）于2017年4月28日发行。2019年2月1日，Sekai Project代理发行该作Steam中/英文版《9-nine-:Episode 1》。

新海天线路，系列第二部《9-nine-天色天歌天籁音》（原名：9-nine-そらいろそらうたそらのおと）于2018年4月27日发行。2019年8月17日，Sekai Project代理发行该作的Steam中/英文版《9-nine-:Episode 2》。

香坂春风线路，系列第三部《9-nine-春色春恋春熙风》（原名：9-nine-はるいろはるこいはるのかぜ）于2019年4月26日发行。

结城希亚线路，系列第四部《9-nine-雪色雪花雪余痕》（原名：9-nine-ゆきいろゆきはなゆきのあと）于2020年4月24日发行。

新章节9-nine-新章（9-nine-New Episode），为接续第四部结尾，观测并改变一切，最后的故事。

## **详细简介：**
第一作：9-nine-九次九日九重色
https://post.qingju.org/PC/023_0/
第二作：9-nine-天色天歌天籁音
https://post.qingju.org/PC/024_0/
第三作：春色春恋春风
https://post.qingju.org/PC/025_0/
第四作：9-nine-雪色雪花雪之痕
https://post.qingju.org/PC/026_0/
第五作：9-nine-新章
https://post.qingju.org/PC/027_0/

KR手机版：
第一作：9-nine-九次九日九重色
https://post.qingju.org/KRKR/025/
第二作：9-nine-天色天歌天籁音
https://post.qingju.org/KRKR/026/
第三作：春色春恋春风
https://post.qingju.org/KRKR/023/
第四作：9-nine-雪色雪花雪之痕
https://post.qingju.org/KRKR/027/
第五作：9-nine-新章
https://post.qingju.org/KRKR/024/
<br>






## <font color=#FF0000 >**注意事项：**</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具win_7Z或RAR进行解压！（这点很重要）
3、PC双击『exe文件』运行游戏，KRKR模拟器点击『data.xp3』运行游戏。
4、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
5、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1VnE_Rc1Hn3F6FZZl3BzNyQ?pwd=4gt1" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:4gt1
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>