---
title: 【安卓直装】【SLG】コハルとの放课後個別指導2-1.0c
categories: 安卓
tags:
- SLG
- 萝莉
- JK
- 动态
- 策略
- 经营模拟
- 2023年
- 狐狐部屋社
date: 2024-4-16 13:01:00
description: 【Live2D】コハルとの放課後個別指導2 Android.Ver一款简单直观的触屏游戏，可以用一只手轻松操作！精美的模型，简单直观的操作和高度可移动范围！没有复杂拖沓的系统，可以自由地在屏幕上移动，动作流畅。
index_img: https://img.acgus.top/i/2024/04/535b47c4769aff4840e98d6278f41eab.webp
---
![](https://img.acgus.top/i/2024/04/535b47c4769aff4840e98d6278f41eab.webp)
## 游戏简介：
【Live2D】コハルとの放課後個別指導2 Android.Ver
一款简单直观的触屏游戏，可以用一只手轻松操作！
精美的模型，简单直观的操作和高度可移动范围！没有复杂拖沓的系统，可以自由地在屏幕上移动，动作流畅。
内容包括一个场景，
许多可调整的显示切换，
CV是 皐月メイ。
<br>




## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1SuITN5jjWWbebYcE42HGmg?pwd=qe41" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:qe41
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>