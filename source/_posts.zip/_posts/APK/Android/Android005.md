---
title: 【安卓直装】【SLG】圣诞老人和白色圣诞节
categories: 安卓
tags:
- SLG
- 萝莉
- 小游戏
- 经营模拟
- 策略
date: 2023-3-31 8:10:00
description: 纸巾盒系列之一，依旧是短小精悍，但是它有配音。又到了一年一次的圣诞节，男主正和平常一样往常在家，突然一个圣诞老人装的少女打破了男主家的玻璃，闯了进来“我是来给你送圣诞礼物的，来拿好”少女说着“可是我还是单身，这礼物没什么用啊”“什么，不会吧，你居然还是单身吗，没办法既然是我送你的礼物，那我就让你体验一下这个礼物的重要性吧”
index_img: https://img.acgus.top/i/2023/07/b424c5f0ef075139.webp
---
![](https://img.acgus.top/i/2023/07/b424c5f0ef075139.webp)
## 游戏简介：
纸巾盒系列之一，依旧是短小精悍，但是它有配音
有到了一年一次的圣诞节，男主正和平常一样往常在家，突然一个圣诞老人装的少女打破了男主家的玻璃，闯了进来
“我是来给你送圣诞礼物的，来拿好”少女说着
“可是我还是单身，这礼物没什么用啊”
“什么，不会吧，你居然还是单身吗，没办法既然是我送你的礼物，那我就让你体验一下这个礼物的重要性吧”
![](https://img.acgus.top/i/2023/07/192f85a04d075645.webp)




## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1Bzdx7NPHKTuCLErHmhJG6Q?pwd=8o7i" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:8o7i
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>
