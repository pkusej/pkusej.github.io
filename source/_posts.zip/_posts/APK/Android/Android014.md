---
title: 【安卓直装】【ACT】FutakenValley／扶她山谷 v0.033.2
categories: 安卓
tags:
- ACT
- 战斗
- 策略
- 小游戏
- 经营模拟
- 像素风
- 触手
- Mofu社
date: 2023-11-18 8:11:00
description: 你需要控制主角逃离丧尸遍布的地方，最终到达避难所。一不小心就会发生不可描述的事情（；´д｀）ゞ
index_img: https://img.acgus.top/i/2023/09/e1b3dbe9b1130428.webp
---
![](https://img.acgus.top/i/2023/09/e1b3dbe9b1130428.webp)
![](https://img.acgus.top/i/2023/09/3f736e5260130607.webp)
## 游戏简介：
由[Mofu]9月发布的最新的一款ACT的遊戲
該游戲是一款動作平台游戲類型游戲。
Nene是一個喜歡蘑菇的扶她女孩，在旅途中她掉進了一個山谷。
她的目標是逃離那里，到達她的目的地，蘑菇村。
◆游戏自带官方中文，无码，部分BOSS有破衣阶段，道具众多，装备后可以改变人物体型，有数值和装备系统.
A : 左 D : 右
S : 下 I : 道具
Space : 跳跃 K :攻击
L : 特殊技 J : 闪避
E、R : 武器切换
Ｍ : 地图 LeftSift : 跑动
ESC :菜单
<br>




## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1JRKZhP5qxbV_FtGIwC_LHA?pwd=9ax9" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:9ax9
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>
