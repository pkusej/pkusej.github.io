---
title: 【安卓直装】【SLG】Jsk-无法逃避的小恶魔
categories: 安卓
tags:
- SLG
- 小游戏
- 经营模拟
- 策略
- 恶魔
date: 2023-1-19 8:01:00
description: 无法逃避的小恶魔安卓汉化版是一款恋爱养成类游戏，精美的游戏画面，二次元的游戏画风，有趣的互动玩法。游戏里玩家将和小恶魔开始幸福的生活，通过各种互动来提升小恶魔与玩家的感情，随着好感度的提升，解锁各种好看的CG动画
index_img: https://img.acgus.top/i/2023/06/3eb076dd7a112339.webp
---
![](https://img.acgus.top/i/2023/06/3eb076dd7a112339.webp)
## 游戏简介：
无法逃避的小恶魔安卓汉化版是一款恋爱养成类游戏，精美的游戏画面，二次元的游戏画风，有趣的互动玩法。游戏里玩家将和小恶魔开始幸福的生活，通过各种互动来提升小恶魔与玩家的感情，随着好感度的提升，解锁各种好看的CG动画
![](https://img.acgus.top/i/2023/06/096216afa1112459-1024x476.webp)





## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1h3d3HaWh2W1G6UYP5xrwwQ?pwd=2hei" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:2hei
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>
