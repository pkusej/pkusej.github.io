---
title: 【安卓直装】milk gallery／牛奶画廊：milk-gallery
categories: 安卓
tags:
- SLG
- 萝莉
- 后宫
- 小游戏
- 触手
- 像素风
date: 2023-11-16 8:10:00
description: 牛奶画廊，本次带来的是unity引擎开发的像素风小游戏（全是小x莉)。与其说这会的是游戏，不如说是像素风的动画更为合适，游戏的玩法也相当简单，一个字——看。游戏内包含多种场景，尽管画风是像素风，但是并不能阻止你社保的步伐，倒不如说像素风的加持之下，画面上的小x莉更加可爱了，而且所有的场景基本上都是x气满满的x爆环节，玩了绝对不亏的好吧。
index_img: https://img.acgus.top/i/2023/09/1386333c4c214626.webp
---
![](https://img.acgus.top/i/2023/09/1386333c4c214626.webp)
![](https://img.acgus.top/i/2023/09/5e76d89b5b214627.webp)
## 游戏简介：
牛奶画廊，本次带来的是unity引擎开发的像素风小游戏（全是小x莉)。与其说这会的是游戏，不如说是像素风的动画更为合适，游戏的玩法也相当简单，一个字——看。游戏内包含多种场景，尽管画风是像素风，但是并不能阻止你社保的步伐，倒不如说像素风的加持之下，画面上的小x莉更加可爱了，而且所有的场景基本上都是x气满满的x爆环节，玩了绝对不亏的好吧。
<br>




## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1AiMo1dDRU2E4HfNGnx-hLA?pwd=xpw1" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:xpw1
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>
