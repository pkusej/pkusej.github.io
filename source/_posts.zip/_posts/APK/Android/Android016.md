---
title: 【安卓直装】冬日恋歌／SNOW
categories: 安卓
tags:
- ADV
- 悬疑
- 田园
- 冬
- 纯爱
- 全年龄
- 2003年
- StudioMebius社
date: 2024-4-16 13:01:00
description: 自古，天上就有龙的存在。龙是掌管雪的公主。某天，她爱上了人间的男子。但是，这段恋情就如同那空中楼阁。龙把白雪降落到人间。将一切埋没在纯白之中。就好像要斩断那对人间男子的思念一般。人间的男子拥有一把巨剑。
index_img: https://img.acgus.top/i/2024/04/40b0928c272e5480132380751281cc92.webp
---
![](https://img.acgus.top/i/2024/04/0bb48d01ed33b767f830c2bd28c81f64.webp)
品牌：StudioMebius
发售日期：2003-01-31
原画：飛鳥ぴょん こぶいち
声优：一色ヒカル 理多 民安ともえ 韮井叶 涼森ちさと 紬叶慧 石井李奈 天天 森川明大 佐倉凛 征十郎 伴風太
剧本：望月JET Klein 神野マサキ
原名：SNOW
又名：冬季恋歌

## 游戏简介：
自古，天上就有龙的存在。
龙是掌管雪的公主。
某天，她爱上了人间的男子。
但是，这段恋情就如同那空中楼阁。
龙把白雪降落到人间。
将一切埋没在纯白之中。
就好像要斩断那对人间男子的思念一般。
人间的男子拥有一把巨剑。
信仰供奉龙的男人。
斩断今世的神剑。
对龙的仰慕直冲云霄。
终于，龙打破禁忌降临人间。
已无法抹去对男人的思念。
两人坠入爱河，不久共结连理，育出了幼小的生命。
但，这段禁断之恋最终画上了一个悲情的句号。
龙受到了应有的惩罚，夫离子散。
传说就这样拉下了大幕，只剩下各种对结局的揣测。
故事，在同一片土地上，千年后的现代展开了。
![](https://img.acgus.top/i/2024/04/729a5d8f8ff8ae837688b5d09e8f51f0.webp)
![](https://img.acgus.top/i/2024/04/e4e4ce9ccec39f82fb562c691e26cbff.webp)





## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<font color=#FF00FF size=3>**请根据安装包内的教程进行安装游戏**</font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1CFTO8Resey9T8sIElmeAVQ?pwd=s591" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:s591
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>