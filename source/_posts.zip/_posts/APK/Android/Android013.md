---
title: 【安卓直装】Syahata's bad day(シャハタ遭難の一日)
categories: 安卓
tags:
- ACT
- 战斗
- 策略
- 小游戏
- 经营模拟
- 像素风
- 触手
- 僵尸
- jashinn社
date: 2023-11-16 8:11:00
description: 你需要控制主角逃离丧尸遍布的地方，最终到达避难所。一不小心就会发生不可描述的事情（；´д｀）ゞ
index_img: https://img.acgus.top/i/2023/09/10e4bda0d7220315.webp
---
![](https://img.acgus.top/i/2023/09/10e4bda0d7220315.webp)
![](https://img.acgus.top/i/2023/09/15e62feaa8220317.webp)
## 游戏简介：
给各位分享一款更新了的ACT游戏的最新版本
Syahata's bad day(シャハタ遭難の一日)
这是一款由[jashinn]制作者在it上众筹发布的测试版
游戏采用2D像素横向卷轴做为游戏元素，但制作水平非常不错
并且有那里面的断面图，可以查看里面有多少jy
看了一眼内容，已经更新不少东西了
游戏介绍：
你需要控制主角逃离丧尸遍布的地方，最终到达避难所。
一不小心就会发生不可描述的事情（；´д｀）ゞ
<br>




## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/18Tqo-z0JyCMh7_vBOS1T9Q?pwd=6eoj" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:6eoj
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>
