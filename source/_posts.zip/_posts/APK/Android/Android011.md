---
title: 【安卓直装】jsk工坊作品合集
categories: 安卓
tags:
- SLG
- 萝莉
- 猫娘
- 小游戏
- 经营模拟
- 策略
date: 2023-10-30 8:10:00
description: JSK工房是日本的一个做小黄油的工作室，做出的作品大部分由FLASH开发，容量小玩法花样多，深受玩家喜爱。游戏大部分是回合制对战的，将不可一世的女人打败，然后尽情的给透了，画风比较古老，虽然设计上有点沙雕，不过对于部分玩家可能会先被游戏虐一下。
index_img: https://img.acgus.top/i/2023/09/54bba92b1c121305.webp
---
![](https://img.acgus.top/i/2023/09/54bba92b1c121305.webp)
## 游戏简介：
JSK工房是日本的一个做小黄油的工作室，做出的作品大部分由FLASH开发，容量小玩法花样多，深受玩家喜爱。游戏大部分是回合制对战的，将不可一世的女人打败，然后尽情的给透了，画风比较古老，虽然设计上有点沙雕，不过对于部分玩家可能会先被游戏虐一下。
游戏基本系统：
基本上都设定了力量，速度，精神，防御这几项能力。
此外没作都有各种特殊的技能，需要花点数学。
这个点数就是每次你打赢或者打输都会给你结算，从新开始就可以获得点数了。

作品目录如下：
- With Imouto 2_1
- Sherry_1.0.0
- Rita_1.0.0
- Mating Admiral Hamakaze_1.0
- Mating Admiral Arashi_1.0
- Imouto-sama Can't Be Refused_1.0.0
- 捕获格斗娘
- 超魔王娘
- 大魔王娘
- 斗技女王蕾米
- 斗技女王赛琳娜
- 封魔少女
- 格斗大小姐卡莲
- 格斗妹
- 红发格斗娘
- 姬将军
- 教室指导
- 精灵女骑士
- 拘问皇女伊莉娜
- 满脸嫌弃的侄女
- 美唯制服剑士
- 魔法少女米亚
- 魔王娘
- 如月由香乃
- 少女狩猎大叔
- 偷窃少女
- 吸血鬼娘
- 小恶魔妹
- 作弊少女
<br>




## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具ZA或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度网盘下载点：</b><a href="https://pan.baidu.com/s/1UY7JP7XMNgfZmykbv-22Qw?pwd=wt33" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码:wt33
<a style="padding: 0" href="https://post.qingju.org/AD/"><img style="max-width:100%" src="https://img.acgus.top/i/2024/07/478f689b8021d8d499ab43d21acf137a.gif" alt=""></a>
<b><font color=#FF0000 size=4>网站所有资源解压密码均为</b></font><b><font color=#FF00FF size=4>qingju</font><font color=#FF0000 ></font></b><br><b><font color=#FF00FF size=4>本站所有文件均为lz4加密格式，不看必解压失败！！请务必阅读以下教程。</b></font><br><b><font color=#000 size=4>解压教程：</b><a href="https://post.qingju.org/tutorial/000/" style="color: #87CEEB;"><b>点击跳转</b></a>
