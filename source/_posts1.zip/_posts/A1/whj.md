---
title: 【万华镜ONS合集】美少女万华镜1、2、2.5、3、4、5	
categories: 游戏系列合集
date: 2021-12-14 00:03:00
tags:
- ADV
- 纯爱
- 拔作
- 恋爱
- 奇幻
- 八宝备仁
- 游戏合集
- ωstar社
description: 玩家将和故事中性格各异的角色一起，解开神秘超自然事件的真相。并逐步了解贯穿整部游戏的核心——万华镜，及其持有者莲华的秘密。
index_img: https://img.acgus.top/i/weiyun/e4ee55cc4c400c0ab01712714c79b518d6d99d34fe596c2485b32b730125873ccfceaad56f2f0ab7b00314699eb7fc1e.webp
---
![](https://img.acgus.top/i/weiyun/f1948f7b5c25a877a7ace854ce86028f6475321329173c6fe69cf5d2cd4eeed2db60c77d97439c612802b149fd7a77e6.webp)
![](https://img.acgus.top/i/weiyun/be3fab6a2f89aba71610f3212e2a0976e7740f76468cd426148cde2ecd64ae03fc9af4cbb80cd5faa6e72ffff6ad5257.webp)
《美少女万华镜》系列是由ωstar, Seikei Production开发的冒险游戏AVG作品。     
中文名：美少女万华镜     
原版名称：美少女万华鏡     
游戏平台：PC     
所属系列：美少女万华镜     
开发商ωstar, Seikei Production     
发行公司：Seikei Production     
主要角色：莲华、深见·夏彦、雾枝、雫、惠、亚璃子、灯露椎、觋夕摩、觋夕莉、菜菜山·萌世歌、月丘·香恋、皇·公晓、高濑·舞斗等     
游戏语言：包含中文字幕、日文语音

## 游戏简介：
这里，是一间带着乡土气息的山间的温泉旅馆。     
因为工作而访问旅馆的恐怖作家深见夏彦，遇见了一个不可思议的美少女・莲华。     
莲华朝深见递出一个万华镜（万花筒）。     
「要看一下这个吗？要看一下你所窥视不到的世界吗？」     
那么，就去看这个万华镜吧……     
那里是一个妖艳的美丽世界。     
在您的眼中所看到的，是由美少女们所编织而成的，稍纵即逝的一瞬间的快乐之光。     
您，有窥视这个世界的勇气吗？     

<font color=#FF0000 size=3>2022.1.31更新万华镜2.5直装版</font>
游戏详细介绍：
直装安卓版：
https://hexo.acgus.top/APK/049_1/
ONS手机版：
https://hexo.acgus.top/ONS/whj1/
https://hexo.acgus.top/ONS/whj2/
https://hexo.acgus.top/ONS/whj2.5/
https://hexo.acgus.top/ONS/whj3/
https://hexo.acgus.top/ONS/whj4/
https://hexo.acgus.top/ONS/whj5/
PC硬盘版：
https://hexo.acgus.top/PC/whj1_0/
https://hexo.acgus.top/PC/whj2_0/
https://hexo.acgus.top/PC/whj2.5_0/
https://hexo.acgus.top/PC/whj3_0/
https://hexo.acgus.top/PC/whj4_0/
https://hexo.acgus.top/PC/whj5_0/
<br>


## <font color=#FF0000 >注意事项：</font>
<font size=3><b>1、未满18岁请自觉关闭本页面！
2、请用专业的解压工具win_7Z或RAR进行解压！（这点很重要）
3、下载文件前请先保存下来，请不要在线解压！！！这样会导致文件被封，对你也没好处！！！
4、有能力请支持正版！</b></font>

## 下载地址：
<font color=#FF00FF size=3><b>已打中文补丁</b></font>
<b>百度下载点：</b><a href="https://pan.baidu.com/s/1O2ZauAad4LxWMd_u3MYT6A?pwd=hxc4" style="color: #87CEEB;"><b>点击跳转</b></a> 提取码：hxc4